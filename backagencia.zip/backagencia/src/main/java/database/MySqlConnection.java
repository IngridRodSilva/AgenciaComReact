package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySqlConnection {
	
	// Strings utlizadas para acesso ao banco
	private static final String url = "jdbc:mysql://localhost:3306/backagencia";
	private static final String user = "root";
	private static final String password = "S3Q8NQAJ47ZQET8";
	
	// Conex�o com o BD (Driver JDBC MYSQL) 
	public static Connection createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver encontrado!");
		
		} catch(ClassNotFoundException e) { 
			System.out.println("Driver n�o encontrado!" + e.getMessage()); }
			
		try {
			Connection connection = DriverManager.getConnection(url, user, password);
			System.out.println("Conex�o com o banco de dados conclu�da com sucesso!");
			return connection;
			
		} catch (SQLException e) {
			System.out.println("Falha na conex�o com o banco de dados" + e.getMessage());
			return null; }
		
		}
 	}

package modelo;

public class Cliente {
	
    private int Id; 
    private String nome;
    private String cpf;
    private String tel;
    private String dataNasc;
    private String endereco;
    private String nomeUser;
    private String email;
    private String senha;
    
    
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel= tel;
	}
	public String getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(String dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getNomeUser() {
		return nomeUser;
	}
	public void setNomeUser(String nomeUser) {
		this.nomeUser = nomeUser;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	//Para mostrar os dados - M�todo toString
	
	@Override
	public String toString() {
		return "Cliente [Id=" + Id + ", nome=" + nome + ", cpf=" + cpf + ", tel=" + tel+ ", dataNasc="
				+ dataNasc + ", endereco=" + endereco + ", nomeUser=" + nomeUser + ", email=" + email + ", senha="
				+ senha + "]";
	}

	
     
    
}

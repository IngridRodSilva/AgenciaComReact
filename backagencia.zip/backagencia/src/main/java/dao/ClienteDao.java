package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import database.MySqlConnection;
import modelo.Cliente;

public class ClienteDao implements InterfaceCrud {
	
	private static Connection connection = MySqlConnection.createConnection();
	private static String sql; //respons�vel pelas instru��es no bd
	
	public static void create(Cliente cliente) {
		sql = "INSERT INTO clientes VALUES (null, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, cliente.getNome());
			preparedStatement.setString(2, cliente.getCpf());
			preparedStatement.setString(3, cliente.getTel());
			preparedStatement.setString(4, cliente.getDataNasc());
			preparedStatement.setString(5, cliente.getEndereco());
			preparedStatement.setString(6, cliente.getNomeUser());
			preparedStatement.setString(7, cliente.getEmail());
			preparedStatement.setString(8, cliente.getSenha());
			
			preparedStatement.executeUpdate();
			
			System.out.println("Inse��o correta no banco de dados!");
			
		} catch (SQLException e) {
			System.out.println("Erro na inser��o dos dados. " + e.getMessage());
		}
		
	}
	
	public static void delete(int clienteId) {
		sql = "DELETE FROM clientes WHERE id = ?"; //Comando SQL sempre em mai�sculo para diferenciar
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setInt(1, clienteId);
			preparedStatement.executeUpdate();
			
			System.out.println("Exclus�o conclu�da com sucesso!");
			
		} catch (SQLException e) {
			System.out.println("Erro ao excluir o cliente! " + e.getMessage());
		}
	}
		
	
	
	public static List<Cliente> find(String pesquisa){
		
		sql = String.format("SELECT * FROM clientes WHERE nome like '%s%%' OR cpf LIKE '%s%%' ", pesquisa, pesquisa);
		List<Cliente> clientes = new ArrayList<Cliente>();
		
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			
			while (resultSet.next()) {
				
				Cliente cliente = new Cliente();
				
				cliente.setId(resultSet.getInt("id"));
				cliente.setNome(resultSet.getString("nome"));
				cliente.setCpf(resultSet.getString("cpf"));
				cliente.setTel(resultSet.getString("tel"));
				cliente.setDataNasc(resultSet.getString("dataNasc"));
				cliente.setEndereco(resultSet.getString("endereco"));
				cliente.setNomeUser(resultSet.getString("nomeUser"));
				cliente.setEmail(resultSet.getString("email"));
				cliente.setSenha(resultSet.getString("senha"));
				
				clientes.add(cliente);
			}
			System.out.println("Clientes encontrados com sucesso");
			return clientes;
			
		} catch(SQLException e) {
			System.out.println("Erro na busca! " + e.getMessage());
			return null;
		}
	}
	
	public static Cliente findByPk(int clienteId) {
	sql = String.format("SELECT * FROM clientes WHERE id = %d ", clienteId);
		
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			Cliente cliente = new Cliente();
			
			while (resultSet.next()) {
				cliente.setId(resultSet.getInt("id"));
				cliente.setNome(resultSet.getString("nome"));
				cliente.setCpf(resultSet.getString("cpf"));
				cliente.setTel(resultSet.getString("tel"));
				cliente.setDataNasc(resultSet.getString("dataNasc"));
				cliente.setEndereco(resultSet.getString("endereco"));
				cliente.setNomeUser(resultSet.getString("nomeUser"));
				cliente.setEmail(resultSet.getString("email"));
				cliente.setSenha(resultSet.getString("senha"));
			}
			
			System.out.println("Busca por �ndice realizada com sucesso!");
			return cliente;
			
	} catch(SQLException e) {
		
			System.out.println("Erro na busca de clientes por �ndice!" + e.getMessage());
			return null; //Sempre devemos retornar 
		}
	}
	
	
	public static void update(Cliente cliente) {
		sql = "UPDATE clientes SET nome=?, cpf=?, nascimento=?, situacao=? WHERE id=?";
		 
		 try {
			 PreparedStatement preparedStatement = connection.prepareStatement(sql);
			 
			 preparedStatement.setString(1, cliente.getNome());
			 preparedStatement.setString(2, cliente.getCpf());
			 preparedStatement.setString(3, cliente.getTel());
			 preparedStatement.setString(4, cliente.getDataNasc());
			 preparedStatement.setString(5, cliente.getEndereco());
			 preparedStatement.setString(6, cliente.getNomeUser());
			 preparedStatement.setString(7, cliente.getEmail());
			 preparedStatement.setString(8, cliente.getSenha());
			 preparedStatement.setInt(9, cliente.getId());
			

			 preparedStatement.executeUpdate();
			 
			 System.out.println("Dados atualizados com sucesso!");
			 
		 } catch(SQLException e) {
			 System.out.println("Erro ao atualizar os dados. " + e.getMessage());
		 }
	}
	
}

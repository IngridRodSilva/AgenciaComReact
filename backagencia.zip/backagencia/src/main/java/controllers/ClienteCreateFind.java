package controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDao;
import modelo.Cliente;


@WebServlet("/CreateFind")
public class ClienteCreateFind extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public ClienteCreateFind() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// CAMPO PESQUISA
		
		String busca = request.getParameter("busca");
		
		if(busca == null) {
			busca = ""; }
		
		List<Cliente> clientes = ClienteDao.find(busca);
		
		request.setAttribute("clientes", clientes);
		RequestDispatcher resquesDispatcher = request.getRequestDispatcher("listar.jsp");
		resquesDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cliente cliente = new Cliente ();
		
		cliente.setNome(request.getParameter("nome"));
		cliente.setCpf(request.getParameter("cpf"));
		cliente.setTel(request.getParameter("tel"));
		cliente.setDataNasc(request.getParameter("dataNasc"));
		cliente.setEndereco(request.getParameter("endereco"));
		cliente.setNomeUser(request.getParameter("nomeUser"));
		cliente.setEmail(request.getParameter("email"));
		cliente.setSenha(request.getParameter("senha"));
		
		ClienteDao.create(cliente);
		
		doGet(request, response);
	}
}
